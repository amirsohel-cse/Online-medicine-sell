<?php $__env->startSection('content'); ?>

        <h3 class=" " style=""><b>My Orders </b></h3>
<hr>


        <table class="table  table-bordered bootstrap-datatable datatable" style="background-color: white">
            <thead>
            <tr>
                <th>Order ID</th>
                <th>Product Name</th>
                <th>Product Price</th>
                <th>Product Quantity</th>
                <th>Status</th>

            </tr>
            </thead>
            <tbody>
            <?php $__currentLoopData = $order_details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v_order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($v_order->order_id); ?></td>
                    <td class="center"><?php echo e($v_order->product_name); ?></td>
                    <td class="center"><?php echo e($v_order->product_price); ?></td>
                    <td class="center"><?php echo e($v_order->product_sales_quantity); ?></td>
                    <td class="center"><?php echo e($v_order->order_status); ?></td>

                </tr>


            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>




<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\medicineZone\resources\views/pages/my_orders.blade.php ENDPATH**/ ?>