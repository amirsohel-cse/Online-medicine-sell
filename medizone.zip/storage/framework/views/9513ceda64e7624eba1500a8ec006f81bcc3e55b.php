<?php $__env->startSection('content'); ?>

        <div class="col-sm-12 padding-right">
                <div class="product-details"><!--product-details-->
                    <div class="col-sm-6">
                        <div class="view-product">
                            <img src="<?php echo e(URL:: to($product_by_details->product_image)); ?>" alt="" />
                            <h3>ZOOM</h3>
                        </div>
                    </div>
                    <div class="col-sm-6">
                        <div class="product-information"><!--/product-information-->
                            <img src="<?php echo e(URL::to('frontend/images/product-details/new.jpg')); ?>" class="newarrival" alt="" />
                            <h2><?php echo e($product_by_details->product_name); ?></h2>
                            <p>Color: <?php echo e($product_by_details->product_color); ?> </p>
                          <img src="<?php echo e(URL::to('frontend/images/product-details/rating.png')); ?>" alt="" />
                            <p></p>
                            <span>
                                <span><?php echo e($product_by_details->product_price); ?> Tk</span>
                                    <form action="<?php echo e(url('/add_to_cart')); ?>" method="post">
                                        <?php echo e(csrf_field()); ?>

									<label>Quantity:</label>
									<input type="text" value="1" name="qty" />
                                     <input type="hidden" name="product_id" value="<?php echo e($product_by_details->product_id); ?>"  />
									<button type="submit" class="btn btn-success btn-fe fault cart center-block">
										<i class="fa fa-shopping-cart"></i> Add to cart
									</button>
                                    </form>
								</span>
                            <p><b>Availability:</b> In Stock</p>
                            <p><b>Condition:</b> New</p>
                            <p><b>Brand: </b><?php echo e($product_by_details->manufacture_name); ?></p>
                            <p><b>Category: </b><?php echo e($product_by_details->category_name); ?></p>
                            <p><b>Size: </b><?php echo e($product_by_details ->product_size); ?></p>
                        </div><!--/product-information-->
                    </div>
                </div><!--/product-details-->






































































<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\medicineZone\resources\views/pages/product_details.blade.php ENDPATH**/ ?>