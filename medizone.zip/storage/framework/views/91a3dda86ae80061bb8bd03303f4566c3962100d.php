<section id="slider" ><!--slider-->
    <div class="container" style="margin-left: -15px">
        <div class="row">


            <div id="carousel-example-generic" class="carousel slide" data-ride="carousel">
                <!-- Indicators -->
                <ol class="carousel-indicators" >
                    <?php
                    $all_published_slider=DB::table('tb1_slider')->where('publication_status',1)->get(); ?>
                    <?php $__currentLoopData = $all_published_slider; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v_slider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li data-target="#carousel-example-generic" data-slide-to="<?php echo e($loop->index); ?>" class="<?php echo e($loop->first ? 'active' : ''); ?>"></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ol>

                <!-- Wrapper for slides -->
                <div class="carousel-inner" role="listbox">
                    <?php $__currentLoopData = $all_published_slider; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v_slider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="item <?php echo e($loop->first ? ' active' : ''); ?>" >
                            <img src="<?php echo e($v_slider->slider_image); ?>" style="width: 100%;height: 100%">
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>

                <!-- Controls -->
                <a class="left carousel-control" href="#carousel-example-generic" role="button" data-slide="prev">
                    <span class="glyphicon glyphicon-chevron-left" aria-hidden="true"></span>
                    <span class="sr-only">Previous</span>
                </a>
                <a class="right carousel-control" href="#carousel-example-generic" role="button" data-slide="next">
                    <span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>
                    <span class="sr-only">Next</span>
                </a>
            </div>

        </div>
    </div>
</section><!--slider-->
<?php /**PATH C:\xampp\htdocs\medicineZone\resources\views/slider.blade.php ENDPATH**/ ?>