<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('pages.modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <script>
        $(function () {
            var btn = $('button[name="btn"]');
            var btn2 = $('button[name="view"]');

            btn.click(function () {
                var id = $(this).val();
                console.log(id);
                if(id){
                    $.ajax({
                        url: '/add_to_cart_home?id=' + id,
                        type: 'get',
                        contentType: 'application/json',
                        success: function (data, textStatus, jQxhr ) {
                            for(item of data){
                                document.getElementById('countlg').innerHTML=item;
                                document.getElementById('count').innerHTML=item;
                            }
                            ('success');
                        },
                        error: function (jqXhr, textStatus, error) {
                            console.log("this is error ---: ", error);
                        }
                    });
                }
            })
            btn2.click(function () {
                var id = $(this).val();
                console.log(id);
                if(id){
                    $.ajax({
                        url: '/modal?id=' + id,
                        type: 'get',
                        contentType: 'application/json',
                        success: function (data, textStatus, jQxhr ) {
                            console.log(data);
                            data = JSON.parse(data);
                            document.getElementById('pimage').src='/'+data.product_image;
                            document.getElementById('mprice').innerHTML=data.product_price;
                            document.getElementById('pname').innerHTML=data.product_name;
                            document.getElementById('ptype').innerHTML=data.type;
                            if(data.pgeneric ==null)
                            {
                                document.getElementById('mgeneric').style.display = "none";
                            }
                            else{
                                document.getElementById("mgeneric").style.display = "block";
                                document.getElementById('pgeneric').innerHTML = data.pgeneric;
                            }

                            if(data.pieces_per_pata==null)
                                document.getElementById('mperpata').style.display = "none";
                            else{
                                document.getElementById("mperpata").style.display = "block";
                                document.getElementById('pperpata').innerHTML = data.pieces_per_pata;
                            }
                            //for quantity
                            if(data.quantity == null)
                                document.getElementById("mquantity").style.display = "none";
                            else {
                                document.getElementById("mquantity").style.display = "block";
                                document.getElementById('quantity').innerHTML = data.quantity;
                            }
                            // for dose
                            if(data.dose==null)
                                document.getElementById("mdose").style.display = "none";
                            else {
                                document.getElementById("mdose").style.display = "block";
                                document.getElementById('pdose').innerHTML = data.dose;
                            }
                            if(data.size == null)
                                document.getElementById("msize").style.display = "none";
                            else {
                                document.getElementById('psize').innerHTML = data.size;
                            }
                            document.getElementById('addid').value=data.product_id;
                        },
                        error: function (jqXhr, textStatus, error) {
                            console.log("this is error ---: ", error);
                        }
                    });
                }
            })

        })
    </script>
    <?php
    $i=0;
    foreach ($product_by_category as $v_product_by_category){
        if($i==0) { $i++; ?>
    <div class="larger" style="border-bottom: 1px solid green;margin-bottom: 20px;padding-top: 10px">
        <h3 class=" text-center center-block" style="text-align: center;color: #1E7145"><b>All <?php echo e($v_product_by_category->category_name); ?> Products</b></h3>
        <br>

    </div> <?php }?>
    <div class="col-sm-3 larger" >
        <div class="product-image-wrapper"style="background-color: white">
            <div class="single-products">
                <div class="productinfo text-center">
                    <img src="<?php echo e(URL:: to($v_product_by_category->product_image)); ?>" alt="" style="height: 150px"/>
                    <h7 style="color: #1E7145"><b><?php echo e($v_product_by_category->product_name); ?></b></h7>
                    <br>
                    <h7><?php echo e($v_product_by_category->type); ?></h7>
                    <?php if($v_product_by_category->dose): ?>
                        <p>(<?php echo e($v_product_by_category->dose); ?>)</p>
                        <?php else: ?>
                        <p>(<?php echo e($v_product_by_category->size); ?> <?php echo e($v_product_by_category->quantity); ?> )</p>
                    <?php endif; ?>
                    <p style="color: black"><b><?php echo e($v_product_by_category->product_price); ?> </b></p>


                        <button type="button" name="btn" value="<?php echo e($v_product_by_category->product_id); ?>"
                                class="btn btn-success btn-fe fault cart center-block">
                            <i class="fa fa-shopping-cart"></i> Add to cart
                        </button>

               </div>
                
                
                
                
                
                
                
            </div>
            <div class="choose">
                <p></p>
                <button data-toggle="modal" data-target="#productModal" type="button" name="view" value="<?php echo e($v_product_by_category->product_id); ?>"
                        class="btn btn-block btn-default ">
                    <i class="fa fa-eye"></i> View Details
                </button>
            </div>
        </div>
        <br>
        <br>
    </div>

    <?php }?>
        <div class="row larger">
            <div class="col-sm-12 text-center">
                <?php echo e($product_by_category->links()); ?>


            </div>
        </div>

    </div><!--features_items-->

    <?php
    $i=0;
    foreach ($product_by_category as $v_product_by_category){
    if($i==0) { $i++; ?>
    <div class="smalled" style="border-bottom: 1px solid green;margin-bottom: 20px;padding-top: 10px">
        <h3 class=" text-center center-block" style="text-align: center;color: #1E7145"><b>All <?php echo e($v_product_by_category->category_name); ?> Products</b></h3>
        <br>

    </div> <?php }?>
    <div class="col-xs-6 smalled" >
        <div class="product-image-wrapper" style="background-color: white" >
            <div class="single-products">
                <div class="productinfo text-center">
                    <img src="<?php echo e(URL:: to($v_product_by_category->product_image)); ?>" alt="" style="height: 150px"/>
                    <h7 style="color: #1E7145"><b><?php echo e($v_product_by_category->product_name); ?></b></h7>
                    <br>
                    <?php if($v_product_by_category->dose): ?>
                        <p>(<?php echo e($v_product_by_category->dose); ?>)</p>
                    <?php else: ?>
                        <p>(<?php echo e($v_product_by_category->size); ?> <?php echo e($v_product_by_category->quantity); ?> )</p>
                    <?php endif; ?>
                    <p style="color: black"><b><?php echo e($v_product_by_category->product_price); ?> </b></p>
                    <form action="<?php echo e(url('/add_to_cart_home/'.$v_product_by_category->product_id)); ?>" method="post">
                        <?php echo e(csrf_field()); ?>

                        <button type="button" name="btn" value="<?php echo e($v_product_by_category->product_id); ?>"
                                class="btn btn-success btn-fe fault cart center-block">
                            <i class="fa fa-shopping-cart"></i> Add to cart
                        </button>
                    </form>
                </div>
                
                
                
                
                
                
                
            </div>
            <div class="choose">
                <p>
                </p>
                <button data-toggle="modal" data-target="#productModal" type="button" name="view" value="<?php echo e($v_product_by_category->product_id); ?>"
                        class="btn btn-block btn-default ">
                    <i class="fa fa-eye"></i> View Details
                </button>
            </div>
        </div>
        <br>
        <br>

    </div>

    <?php }?>
    <div class="row smalled">
        <div class="col-xs-12 text-center" style="color: #1E7145">
            <?php echo e($product_by_category->links()); ?>


        </div>
    </div>

    </div>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\medicineZone\resources\views/pages/product_by_category.blade.php ENDPATH**/ ?>