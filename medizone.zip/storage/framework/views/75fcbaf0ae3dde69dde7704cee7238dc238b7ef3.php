<?php $__env->startSection('content'); ?>
    <section id="cart_items">
        <div class="container">


            <div class="register-req">
                <p class="align-center">Please fill up this form </p>
            </div><!--/register-req-->

            <div class="shopper-informations">
                <div class="row">

                    <div class="col-sm-12 clearfix">
                        <div class="bill-to">
                            <p>Bill To</p>
                            <div class="form-one">
                                <form>
                                    <input type="text" placeholder="Full Name *">
                                    <input type="text" placeholder="Mobile Phone 1*">
                                    <input type="text" placeholder="Mobile Phone 2 *">
                                    <input type="text" placeholder="Email*">
                                    <input type="text" placeholder="Address 1 *">
                                    <input type="text" placeholder="Address 2">
                                    <input type="text" placeholder="Zip / Postal Code *">
                                    <select>
                                        <option>-- Area --</option>
                                        <option>Mirpur</option>
                                        <option>Dhanmondi</option>
                                        <option>Uttara</option>
                                    </select>
                                </form>
                            </div>
                            <div class="form-two">

                            </div>
                        </div>
                    </div>

                </div>
            </div>
            <div class="review-payment">
                <h2>Review & Payment</h2>
            </div>


        </div>
    </section> <!--/#cart_items-->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\xampp\htdocs\medicineZone\resources\views/pages/checkout.blade.php ENDPATH**/ ?>