<?php $__env->startSection('content'); ?>


    <div class="row">
        <div class="col-md-12">
            <h3 class="h1 heading-primary mt-xl"><strong>Pertners</strong></h3>
            <br>
            <br>
           <ol>
               <li style="font-size: large">
                   Warda Pharmacy, Shenpara Porbota, Mirpur-10, Dhaka.
               </li>
               <br>
               <li style="font-size: large">
                   Polin International, South Monipur, Mirpur, Dhaka
               </li>
               <br>
               <li style="font-size: large">
                   Well Pharma, South Monipur, Mirpur, Dhaka
               </li>
               <br>
               <br>
           </ol>

        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\medicineZone\resources\views/pages/partners.blade.php ENDPATH**/ ?>