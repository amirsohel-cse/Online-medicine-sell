<?php $__env->startSection('content'); ?>

    <section ><!--form-->
        <div class="container" >

   <div class="col-sm-3"></div>
    <div class="col-sm-6">
        <div class="signup-form"><!--sign up form-->
            <h2>Account Information !</h2>
            <p class="alert-success" >
                <?php
                $message = Session::get('messege');

                if($message)
                {
                    echo $message;
                    Session::put('messege',NULL);
                }
                ?>
            </p>

            <?php

            $customer_id=Session::get('customer_id');
            $profile = DB::table('tb1_customer')->where('customer_id',$customer_id)->get();

            foreach($profile as $x) {?>
            <form action="<?php echo e(URL::to('/profile_update/'.$customer_id)); ?>" method="post">
                <?php echo e(csrf_field()); ?>



                <div class="form-group">
                    <label>Full Name:</label>
                    <input class="form-control " type="text" name="fullname" value="<?php echo e($x->customer_name); ?>"/>
                    <span class="Error"></span>
                </div>

                <div class="form-group">
                    <label>Mobile Number:</label>
                    <input class="form-control" type="text" name="mobile" value="<?php echo e($x->customer_mobile_number); ?>"/>
                    <span class="Error"></span>
                </div>
                <div class="form-group">
                    <label>Email:</label>
                    <input class="form-control" type="email" name="email" value="<?php echo e($x->customer_email); ?>"/>
                    <span class="Error"></span>
                </div>
                <div class="form-group">
                    <label>Password:</label>
                    <input class="form-control" type="password" name="password" value="<?php echo e($x->customer_password); ?>"/>
                    <span class="Error"></span>
                </div>
                <button type="submit" class="btn btn-default example4 btn-success">Update</button>
<?php } ?>
            </form>

        </div><!--/sign up form-->
    </div>
            </div>
        <br>
        <br>

    </section>
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\medicineZone\resources\views/pages/profile.blade.php ENDPATH**/ ?>